//
//  CalendarInfoViewController.m
//  BloodDonor
//
//  Created by Andrey Rebrik on 15.08.12.
//
//

#import "CalendarInfoViewController.h"

@interface CalendarInfoViewController ()

@end

@implementation CalendarInfoViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (IBAction)backButtonClick:(id)sender
{
    [self.navigationController popViewControllerAnimated:NO];
}

- (void)dealloc
{
    [sTabBarController release];
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    sTabBarController = [[STabBarController alloc] init];
    sTabBarController.viewController = self;
    [sTabBarController addSubview];
    
    scrollView.contentSize = contentView.frame.size;
    [scrollView addSubview:contentView];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    [sTabBarController addSubview];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [sTabBarController removeSubviews];
    
    [super viewDidDisappear:animated];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
